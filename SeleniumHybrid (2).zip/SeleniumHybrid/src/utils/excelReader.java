package utils;

import java.io.FileInputStream;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class excelReader {

	public static void readExcel()
	{

		HashMap<String, TestCase> tcase = new HashMap<>();
		
		try
		{
			
			FileInputStream fs =new FileInputStream("C:\\Users\\SHREYASH\\Desktop\\selenium environment\\testcases.xls");
			HSSFWorkbook book = new HSSFWorkbook(fs);
			HSSFSheet sheet = book.getSheetAt(0);
			int rc;
			rc =sheet.getPhysicalNumberOfRows();
			
			String tid;
			String testcase;
			String prereq;
			String steps;
			String input;
			String expout;
			
			for(int i=1;i<rc;i++)
			{
				HSSFRow row = sheet.getRow(i);
				
				HSSFCell cel = row.getCell(0);				
				tid =cel.getStringCellValue();
				
				cel = row.getCell(1);
				testcase =cel.getStringCellValue();
				
				cel = row.getCell(2);
				prereq=cel.getStringCellValue();
				
				
				cel = row.getCell(3);
				steps =cel.getStringCellValue();
				
				
				cel = row.getCell(4);
				input =cel.getStringCellValue();
				
				cel = row.getCell(5);
				expout =cel.getStringCellValue();
				
				tcase.put(tid,new TestCase(tid, testcase, prereq, steps, input, expout));
				
			}
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
}
