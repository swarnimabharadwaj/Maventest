package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class pomEvent {
	
	public static WebElement findWebElement(WebDriver driver, String key, String value)
	{
		WebElement el = null;
		
		key=key.toUpperCase();
		
		switch (key) 
		{
			case "ID":
				el =driver.findElement(By.id(value));
				
				break;
			case "NAME":
				el =driver.findElement(By.name(value));
				break;
			case "XPATH":
				el =driver.findElement(By.xpath(value));
				break;
			case "CLASSNAME":
				el =driver.findElement(By.className(value));
				break;
			case "LINKTEXT":
				el =driver.findElement(By.linkText(value));
				break;
				
			case "PARTIALLINKTEXT":
				el =driver.findElement(By.partialLinkText(value));
				break;
			case "CSSSELECTOR":
				el =driver.findElement(By.cssSelector(value));
				break;
				
			default:
				break;
		}
		return el;
		
		
		
	}
	
	public static void webAction(WebElement el, String key, String value)
	{
		
		key=key.toUpperCase();
		switch (key) {
		case "CLICK":
			el.click();
			break;
		case "SENDKEYS":
			el.sendKeys(value);
			break;
		case "CLEAR":
			el.clear();
			break;
			

		default:
			break;
		}
	}

}
